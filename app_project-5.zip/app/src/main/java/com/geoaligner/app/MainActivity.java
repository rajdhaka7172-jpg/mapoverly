package com.geoaligner.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.PixelCopy;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final int FILE_REQ = 1001;

    private FrameLayout root;
    private WebView app;
    private WebView portal;
    private LinearLayout portalBox;
    private TextView portalTitle;
    private ValueCallback<Uri[]> filePathCb;
    private WebViewAssetLoader loader;
    private File capDir;
    private String portalUrl = "";
    private volatile String lastCoord = "";
    private volatile String lastNames = "";

    // मुख्य पेज में: प्रिंट, नई विंडो और डाउनलोड को ऐप से जोड़ना
    private static final String SHIM =
            "(function(){if(window.__shim)return;window.__shim=1;"
          + "window.print=function(){Android.print();};"
          + "window.open=function(u){if(u)Android.openPortal(String(u));return null;};"
          + "var oc=HTMLAnchorElement.prototype.click;"
          + "HTMLAnchorElement.prototype.click=function(){"
          + "if(this.hasAttribute('download')&&/^blob:/.test(this.href)){"
          + "var n=this.getAttribute('download')||'file';"
          + "fetch(this.href).then(function(r){return r.blob();}).then(function(b){"
          + "var fr=new FileReader();"
          + "fr.onload=function(){Android.saveFile(n,String(fr.result).split(',')[1]||'',b.type||'application/octet-stream');};"
          + "fr.readAsDataURL(b);});"
          + "return;}"
          + "return oc.apply(this,arguments);};"
          + "})();";

    // पोर्टल पेज में: कोऑर्डिनेट और "जिला / तहसील / गाँव" की लाइन पढ़ना
    private static final String SCRAPE =
            "(function(){if(window.__scr)return;window.__scr=1;"
          + "function grab(){try{var t=(document.body&&document.body.innerText)||'';"
          + "var m=t.match(/(\\d{5,7}\\.\\d+)\\s*,\\s*(\\d{6,8}\\.\\d+)/);"
          + "var l=t.match(/जिला\\s*:\\s*([^,\\n]+?)\\s*,\\s*तहसील\\s*:\\s*([^,\\n]+?)\\s*,[\\s\\S]{0,300}?गा[ँं]व\\s*:\\s*([^\\n\\r,]+)/);"
          + "AndroidPortal.info(m?(m[1]+','+m[2]):'',l?(l[1]+'|'+l[2]+'|'+l[3]):'');}catch(e){}}"
          + "setInterval(grab,1200);grab();})();";

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void toast(final String s) {
        runOnUiThread(new Runnable() {
            @Override public void run() { Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show(); }
        });
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        capDir = new File(getCacheDir(), "cap");
        capDir.mkdirs();
        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/cap/", new WebViewAssetLoader.InternalStoragePathHandler(this, capDir))
                .build();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        app = new WebView(this);
        setupApp();
        root.addView(app, new FrameLayout.LayoutParams(-1, -1));

        buildPortalUi();
        setContentView(root);
        app.loadUrl("https://" + HOST + "/assets/index.html");
    }

    private void setupApp() {
        WebSettings s = app.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        app.addJavascriptInterface(new Bridge(), "Android");
        app.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                showPortal(u.toString());
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(SHIM, null);
            }
        });
        app.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(Intent.createChooser(i, "फ़ाइल चुनें"), FILE_REQ);
                } catch (Exception e) {
                    filePathCb = null;
                    return false;
                }
                return true;
            }
        });
    }

    private Button mkBtn(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(0x26FFFFFF);
        b.setAllCaps(false);
        b.setTextSize(18);
        b.setPadding(0, 0, 0, 0);
        return b;
    }

    private void buildPortalUi() {
        portalBox = new LinearLayout(this);
        portalBox.setOrientation(LinearLayout.VERTICAL);
        portalBox.setBackgroundColor(Color.WHITE);
        portalBox.setVisibility(View.GONE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF0F3D33);
        bar.setPadding(dp(6), dp(6), dp(6), dp(6));

        Button back = mkBtn("◀");
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (portal.canGoBack()) portal.goBack();
                else toast("पीछे जाने के लिए कोई पेज नहीं है");
            }
        });
        Button home = mkBtn("⌂");
        home.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (portalUrl.length() > 0) portal.loadUrl(portalUrl);
            }
        });
        portalTitle = new TextView(this);
        portalTitle.setTextColor(Color.WHITE);
        portalTitle.setTextSize(15);
        portalTitle.setSingleLine(true);
        portalTitle.setPadding(dp(8), 0, dp(8), 0);
        Button reload = mkBtn("⟳");
        reload.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { portal.reload(); }
        });
        Button close = mkBtn("✕");
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closePortal(); }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        bar.addView(home, new LinearLayout.LayoutParams(dp(44), dp(44)));
        bar.addView(portalTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(reload, new LinearLayout.LayoutParams(dp(44), dp(44)));
        bar.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));

        portal = new WebView(this);
        setupPortal();

        Button cap = new Button(this);
        cap.setText("▣  DIRECTLY OVERLAP WHOLE MAP");
        cap.setTextColor(Color.WHITE);
        cap.setBackgroundColor(0xFF0D3B2E);
        cap.setAllCaps(false);
        cap.setTextSize(16);
        cap.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { capturePortal(); }
        });

        portalBox.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        portalBox.addView(portal, new LinearLayout.LayoutParams(-1, 0, 1f));
        portalBox.addView(cap, new LinearLayout.LayoutParams(-1, dp(56)));
        root.addView(portalBox, new FrameLayout.LayoutParams(-1, -1));
    }

    private void setupPortal() {
        WebSettings s = portal.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(portal, true);
        portal.addJavascriptInterface(new PortalInfo(), "AndroidPortal");
        portal.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                String t = v.getTitle();
                portalTitle.setText((t == null || t.length() == 0) ? Uri.parse(url).getHost() : t);
                v.evaluateJavascript(SCRAPE, null);
            }
        });
        portal.setWebChromeClient(new WebChromeClient());
        portal.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                try {
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    r.setMimeType(mime);
                    String cookie = CookieManager.getInstance().getCookie(url);
                    if (cookie != null) r.addRequestHeader("cookie", cookie);
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                            URLUtil.guessFileName(url, cd, mime));
                    ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                    toast("डाउनलोड शुरू हुआ (Downloads में मिलेगा)");
                } catch (Exception e) {
                    toast("डाउनलोड नहीं हो पाया: " + e.getMessage());
                }
            }
        });
    }

    private void showPortal(String url) {
        portalBox.setVisibility(View.VISIBLE);
        if (!url.equals(portalUrl)) {
            portalUrl = url;
            portalTitle.setText(Uri.parse(url).getHost());
            portal.loadUrl(url);
        }
    }

    private void closePortal() {
        portalBox.setVisibility(View.GONE);
    }

    private void capturePortal() {
        final int w = portal.getWidth();
        final int h = portal.getHeight();
        if (w <= 0 || h <= 0) return;
        final Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        int[] loc = new int[2];
        portal.getLocationInWindow(loc);
        Rect r = new Rect(loc[0], loc[1], loc[0] + w, loc[1] + h);
        try {
            PixelCopy.request(getWindow(), r, bmp, new PixelCopy.OnPixelCopyFinishedListener() {
                @Override
                public void onPixelCopyFinished(int result) {
                    if (result == PixelCopy.SUCCESS) finishCapture(bmp);
                    else toast("कैप्चर नहीं हो पाया, दोबारा दबाएँ");
                }
            }, new Handler(Looper.getMainLooper()));
        } catch (Throwable t) {
            Canvas c = new Canvas(bmp);
            portal.draw(c);
            finishCapture(bmp);
        }
    }

    private void finishCapture(final Bitmap bmp) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    File f = new File(capDir, "portal.png");
                    FileOutputStream o = new FileOutputStream(f);
                    try {
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, o);
                    } finally {
                        o.close();
                    }
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            portalBox.setVisibility(View.GONE);
                            app.evaluateJavascript("window.onPortalInfo&&window.onPortalInfo("
                                    + JSONObject.quote(lastCoord) + "," + JSONObject.quote(lastNames) + ")", null);
                            app.evaluateJavascript("window.onPortalCapture&&window.onPortalCapture('https://"
                                    + HOST + "/cap/portal.png?t=" + System.currentTimeMillis() + "')", null);
                        }
                    });
                } catch (Exception e) {
                    toast("कैप्चर सेव नहीं हो पाया");
                }
            }
        }).start();
    }

    private void doPrint() {
        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        PrintDocumentAdapter adapter = app.createPrintDocumentAdapter("GeoAligner");
        pm.print("GeoAligner", adapter,
                new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
    }

    public class PortalInfo {
        @JavascriptInterface
        public void info(String coord, String names) {
            lastCoord = coord == null ? "" : coord;
            lastNames = names == null ? "" : names;
        }
    }

    public class Bridge {
        @JavascriptInterface
        public void openPortal(final String url) {
            runOnUiThread(new Runnable() {
                @Override public void run() { showPortal(url); }
            });
        }

        @JavascriptInterface
        public void print() {
            runOnUiThread(new Runnable() {
                @Override public void run() { doPrint(); }
            });
        }

        @JavascriptInterface
        public void saveFile(final String name, final String b64, final String mime) {
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        byte[] data = Base64.decode(b64, Base64.DEFAULT);
                        String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
                        if (Build.VERSION.SDK_INT >= 29) {
                            ContentValues v = new ContentValues();
                            v.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                            OutputStream o = getContentResolver().openOutputStream(uri);
                            try {
                                o.write(data);
                            } finally {
                                o.close();
                            }
                        } else {
                            File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                            FileOutputStream o = new FileOutputStream(new File(dir, safe));
                            try {
                                o.write(data);
                            } finally {
                                o.close();
                            }
                        }
                        toast("Downloads में सेव हुआ: " + safe);
                    } catch (Exception e) {
                        toast("सेव नहीं हो पाया: " + e.getMessage());
                    }
                }
            }).start();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ && filePathCb != null) {
            filePathCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            filePathCb = null;
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (portalBox.getVisibility() == View.VISIBLE) {
            if (portal.canGoBack()) portal.goBack();
            else closePortal();
        } else if (app.canGoBack()) {
            app.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
